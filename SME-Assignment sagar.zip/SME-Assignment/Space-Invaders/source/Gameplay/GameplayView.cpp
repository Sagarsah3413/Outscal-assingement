#include "../../header/Gameplay/GameplayView.h"
#include "../../header/Global/ServiceLocator.h"
#include "../../header/Global/Config.h"
#include "../../header/Graphics/GraphicService.h"

namespace Gameplay
{
	using namespace UI::UIElement;
	using namespace Global;

	GameplayView::GameplayView()
		: game_window(nullptr),
		gameplay_controller(nullptr),
		background_image(new ImageView()) // Initialize background_image
	{
	}
	

	GameplayView::~GameplayView() { delete (background_image);  background_image = nullptr;}

	void GameplayView::initialize() { initializeBackgroundImage(); }

	void GameplayView::initializeBackgroundImage()
	{
		sf::RenderWindow* game_window = ServiceLocator::getInstance()->getGraphicService()->getGameWindow();

		background_image->initialize(Config::background_texture_path,
			game_window->getSize().x,
			game_window->getSize().y,
			sf::Vector2f(0, 0));

		background_image->setImageAlpha(static_cast<float>(background_alpha));
	}

	void GameplayView::update() { background_image->update(); }

	void GameplayView::render() { background_image->render(); }
}