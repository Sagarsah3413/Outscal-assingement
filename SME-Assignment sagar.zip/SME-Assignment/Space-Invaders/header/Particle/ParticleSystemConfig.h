#pragma once

namespace Particle
{
    struct ParticleSystemConfig 
    {
        sf::String particles_texture_path;

        float frame_duration = 0.0f;
        int number_of_animation_frames = 0;
        float particles_sprite_height = 0.0f;
        float particles_sprite_width = 0.0f;
        float tile_height = 0.0f;
        float tile_width = 0.0f;

        ParticleSystemConfig() = default;

        ParticleSystemConfig(sf::String texture_path,
            float sprite_width,
            float sprite_height,
            float tile_width_param,
            float tile_height_param,
            int frames,
            float duration)
            : particles_texture_path(texture_path),
            particles_sprite_width(std::max(0.0f, sprite_width)), // Ensure non-negative
            particles_sprite_height(std::max(0.0f, sprite_height)),
            tile_width(std::max(0.0f, tile_width_param)),
            tile_height(std::max(0.0f, tile_height_param)),
            number_of_animation_frames(std::max(0, frames)), // Initialize number_of_animation_frames
            frame_duration(std::max(0.0f, duration)) {}  // Initialize frame_duration

    };
}