#pragma once
#include "SFML/Graphics/Text.hpp"

namespace Gameplay
{
    struct HighScoreData
    {
        std::string player_name;
        int score=0;
    };

    class HighScore // Change from static class to class
    {
    public:
        static void saveHighScore(const HighScoreData& highScore);
        static HighScoreData loadHighScore(); // Add static keyword
    };
}
