//PlayerModel.h

#pragma once
#include <SFML/Graphics.hpp>
#include "../../header/Entity/EntityConfig.h"
#include "../../header/UI/GameplayUI/GameplayUIController.h"

namespace Player {

    enum class PlayerState {
        ALIVE,
        FROZEN,
        DEAD,
    };

    class PlayerModel {
    private:
        friend class PlayerController;
        friend void UI::GameplayUI::GameplayUIController::updateScoreText();
        friend void UI::GameplayUI::GameplayUIController::updateEnemiesKilledText();
        friend void UI::GameplayUI::GameplayUIController::drawPlayerLives();

        static int player_lives;
        static int player_score;
        static int enemies_killed;
        static int bullets_fired;

        const sf::Vector2f initial_player_position = sf::Vector2f(950.f, 950.f);
        sf::Vector2f player_position = initial_player_position;
        Entity::EntityType entity_type;
        PlayerState player_state = PlayerState::ALIVE;

        bool b_shield = false;
        bool b_rapid_fire = false;
        bool b_tripple_laser = false;

    public:
        // Constants initialized in place, using float to maintain precision
        const sf::Vector2f left_most_position = sf::Vector2f(50.f, 950.f);
        const sf::Vector2f right_most_position = sf::Vector2f(1800.f, 950.f);
        const sf::Vector2f barrel_position_offset = sf::Vector2f(20.f, 5.f);
        const sf::Vector2f second_weapon_position_offset = sf::Vector2f(45.f, 0.f);
        const sf::Vector2f third_weapon_position_offset = sf::Vector2f(-45.f, 0.f);
        static const int max_player_lives;
        const float shield_powerup_duration = 10.f;
        const float rapid_fire_powerup_duration = 10.f;
        const float tripple_laser_powerup_duration = 10.f;

        const float freeze_duration = 1.5f;

        const float fire_cooldown_duration = 0.2f;
        const float rapid_fire_cooldown_duration = 0.05f;
        const float tripple_laser_position_offset = 30.f;

        const float player_movement_speed = 350.0f;
        static const int invincible_player_alpha = 170;  // Keeping it int, but use float if necessary

        PlayerModel();
        ~PlayerModel();

        void initialize();
        void reset();

        sf::Vector2f getPlayerPosition() ;
        void setPlayerPosition(const sf::Vector2f& position);
        


        PlayerState getPlayerState() const;
        void setPlayerState(PlayerState state);

        Entity::EntityType getEntityType() const;

        bool isShieldEnabled() const;
        bool isRapidFireEnabled() const;
        bool isTrippleLaserEnabled() const;

        void setShieldState(bool value);
        void setRapidFireState(bool value);
        void setTrippleFireState(bool value);
    };
}
