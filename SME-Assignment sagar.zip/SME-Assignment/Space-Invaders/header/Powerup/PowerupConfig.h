#pragma once

namespace Powerup
{
	enum class PowerupType
	{
		SHIELD,
		RAPID_FIRE,
		TRIPPLE_LASER,
		OUTSCAL_BOMB,
	};
}