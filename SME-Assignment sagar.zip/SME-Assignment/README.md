# SME-Assignment

# Space-Invaders Project Debugging Report

## Debugging Process

### Initial Assessment

Upon initial inspection, the project exhibited several issues, including:

- Uninitialized variables leading to compiler warnings.
- Syntax errors causing compilation failures.
- Type conversion warnings indicating potential data loss.
- Unresolved external symbols during the linking phase.

### Debugging Steps

1. **Identifying Issues**: Reviewed compiler output and codebase to identify specific problem areas.
2. **Addressing Uninitialized Variables**: Initialized critical variables in classes such as `ParticleSystemConfig`, `sf::Glyph`, and `GameplayView` to eliminate uninitialized variable warnings.
3. **Correcting Syntax Errors**: Fixed syntax errors in the `PlayerController.h` header file by ensuring proper declaration of class members.
4. **Handling Type Conversion Warnings**: Added explicit type casts where necessary to address type conversion warnings and ensure data integrity.
5. **Resolving Linker Errors**: Provided proper definitions for static member variables to resolve linker errors related to unresolved external symbols.

## Changes Made

The following changes were implemented to address the identified issues:

- Initialization of variables in critical classes.
- Correction of syntax errors in header files.
- Addition of explicit type casts to handle type conversion warnings.
- Provision of proper definitions for static member variables to resolve linker errors.

## Current Status

After implementing the changes, the project has achieved a more stable state. However, some warnings and unresolved external symbols persist, requiring further investigation and potential collaboration with the SFML community for resolution.

## Conclusion

The debugging process has significantly improved the stability and functionality of the Space-Invaders project. By addressing the identified issues, the project now offers a more seamless gaming experience. Further collaboration and testing will be required to fully resolve the remaining warnings and linker errors.
